import React from 'react'
import SinglePost from './SinglePost'

const AllPosts = () => {
  return (
    <>
      <div className="_feed_inner_timeline_post_area _b_radious6 _padd_b24 _padd_t24 _mar_b16">
        <SinglePost></SinglePost>
      </div>
    </>
  )
}

export default AllPosts